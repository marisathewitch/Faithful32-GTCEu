# Faithful32-GTCEu
Faithful32 GTCEu attempt.

Faithful 32 resource pack for GregTech CE: Unofficial.

All credit goes to Faithful-Mods, Ethryan and UserNM.
They do 99.9% of all work.
